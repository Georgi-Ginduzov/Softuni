﻿namespace Telephony
{
    public interface ICallable
    {
        public string Call(string phoneNumber);
    }
}

﻿namespace Telephony
{
    public interface IBrowsable : ICallable
    {
        string Browse(string url);
    }
}

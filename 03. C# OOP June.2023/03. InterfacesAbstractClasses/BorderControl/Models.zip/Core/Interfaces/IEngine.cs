﻿namespace E04._BorderControl.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}

﻿namespace E04._BorderControl.IO.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}

﻿using InfluencerManagerApp.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InfluencerManagerApp.Models
{
    public abstract class Campaign : ICampaign
    {
        private string brand;
        private double budget;
        private List<string> contributors;
        public Campaign(string brand, double budget)
        {
            Brand = brand;
            Budget = budget;
            contributors = new List<string>();
        }

        public string Brand 
        {
            get => brand;
            private set
            {
                if (String.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException("Brand is required.");
                }

                brand = value;
            } 
        }

        public double Budget 
        {
            get => budget;
            private set => budget = value;
        }

        public IReadOnlyCollection<string> Contributors => contributors;

        public void Engage(IInfluencer influencer)
        {
            contributors.Add(influencer.Username);

            /* void Engage(IInfluencer influencer)
            This method enables the campaign to collaborate with influencers.When invoked, it includes the username of the influencer in the collection of contributors. You have to take the campaign price calculated amount.Decreases the campaign’s budget by the amount, representing expenditures such as influencer fees.
            */



        }

        public void Gain(double amount) => Budget += amount;

        public override string ToString()
        {
            return $"{GetType().Name} - Brand: {Brand}, Budget: {Budget}, Contributors: {Contributors.Count}".Trim();
        }
    }
}

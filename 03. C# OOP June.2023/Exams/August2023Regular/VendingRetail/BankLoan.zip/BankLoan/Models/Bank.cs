﻿using BankLoan.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BankLoan.Models
{
    public abstract class Bank : IBank
    {
        private string name;
        private int capacity;
        
        public Bank(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Loans = new List<ILoan>();
            Clients = new List<IClient>();
        }

        public string Name 
        { 
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    System.Console.WriteLine("Bank name cannot be null or empty.");
                }
                // All names are unique
                name = value;
            }
        }

        public int Capacity 
        { 
            get => capacity; 
            private set => capacity = value; 
        }

        public IReadOnlyCollection<ILoan> Loans { get; set; } // ;

        public IReadOnlyCollection<IClient> Clients { get; set; } // ;

        public void AddClient(IClient Client)
        {
            if (Clients.Count < Capacity)
            {
                Clients.Add(Client);
            }
            else
            {
                throw new ArgumentException("Not enough capacity for this client.");
            }
        }

        public void AddLoan(ILoan loan)
        {
            throw new System.NotImplementedException();
        }

        public string GetStatistics()
        {
            throw new System.NotImplementedException();
        }

        public void RemoveClient(IClient Client)
        {
            throw new System.NotImplementedException();
        }

        public double SumRates()
        {
            return Loans.Sum(l => l.InterestRate);
        }
    }
}
